import { GoogleGenAI, Type, Modality } from "@google/genai";
import { LeadFormData } from '../types';

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
};

export const parseLeadInfo = async (text: string): Promise<Partial<LeadFormData>> => {
  try {
    const ai = getAiClient();
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Extract real estate lead information from the following text: "${text}". 
      
      Infer the property type if mentioned (House, Apartment, Condo, Commercial, Land). If not specified, use 'Other'.
      If a field is missing, omit it.
      
      For the phone number, try to extract the country code if present (e.g. +91 for India, +1 for US). If a local number is provided without a code, just return the number.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING, description: "Full name of the lead" },
            phone: { type: Type.STRING, description: "Phone number with country code if available (e.g. +91 98765 43210)" },
            city: { type: Type.STRING, description: "City or location of interest" },
            propertyType: { 
              type: Type.STRING, 
              enum: ['House', 'Apartment', 'Condo', 'Commercial', 'Land', 'Other'],
              description: "Type of property interested in" 
            }
          }
        }
      }
    });

    if (response.text) {
        return JSON.parse(response.text) as Partial<LeadFormData>;
    }
    return {};
  } catch (error) {
    console.error("AI Parsing Error:", error);
    throw error;
  }
};

export const generateScript = async (city: string, budget: string, propertyType: string): Promise<string> => {
  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Write a professional real estate cold calling script.
      Context: Agent is looking for ${propertyType} properties in ${city} for a client with a budget of ${budget}.
      
      Structure the response clearly with these sections:
      1. Opening (The Hook)
      2. The Pitch (Buyer Needs)
      3. Scenarios:
         - Scenario A: They are interested (What to ask next)
         - Scenario B: They say "No" (Objection handling)
         - Scenario C: "Not Interested" or "Busy" (Polite exit/follow-up)
      
      Keep the tone professional, empathetic, and direct.`,
    });
    return response.text || "Failed to generate script.";
  } catch (error) {
    console.error("AI Script Generation Error:", error);
    throw error;
  }
};

// Helper to convert Base64 Int16 PCM to WAV Blob
const createWavFile = (base64Data: string, sampleRate: number = 24000): Blob => {
  const binaryString = atob(base64Data);
  const len = binaryString.length;
  const buffer = new ArrayBuffer(len);
  const view = new DataView(buffer);
  
  for (let i = 0; i < len; i++) {
    view.setUint8(i, binaryString.charCodeAt(i));
  }

  // WAV Header construction
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = sampleRate * numChannels * (bitsPerSample / 8);
  const blockAlign = numChannels * (bitsPerSample / 8);
  const dataSize = len;
  
  const wavBuffer = new ArrayBuffer(44 + dataSize);
  const wavView = new DataView(wavBuffer);

  // RIFF Chunk
  wavView.setUint8(0, 'R'.charCodeAt(0));
  wavView.setUint8(1, 'I'.charCodeAt(0));
  wavView.setUint8(2, 'F'.charCodeAt(0));
  wavView.setUint8(3, 'F'.charCodeAt(0));
  wavView.setUint32(4, 36 + dataSize, true); // ChunkSize
  wavView.setUint8(8, 'W'.charCodeAt(0));
  wavView.setUint8(9, 'A'.charCodeAt(0));
  wavView.setUint8(10, 'V'.charCodeAt(0));
  wavView.setUint8(11, 'E'.charCodeAt(0));

  // fmt Subchunk
  wavView.setUint8(12, 'f'.charCodeAt(0));
  wavView.setUint8(13, 'm'.charCodeAt(0));
  wavView.setUint8(14, 't'.charCodeAt(0));
  wavView.setUint8(15, ' '.charCodeAt(0));
  wavView.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  wavView.setUint16(20, 1, true); // AudioFormat (1 for PCM)
  wavView.setUint16(22, numChannels, true); // NumChannels
  wavView.setUint32(24, sampleRate, true); // SampleRate
  wavView.setUint32(28, byteRate, true); // ByteRate
  wavView.setUint16(32, blockAlign, true); // BlockAlign
  wavView.setUint16(34, bitsPerSample, true); // BitsPerSample

  // data Subchunk
  wavView.setUint8(36, 'd'.charCodeAt(0));
  wavView.setUint8(37, 'a'.charCodeAt(0));
  wavView.setUint8(38, 't'.charCodeAt(0));
  wavView.setUint8(39, 'a'.charCodeAt(0));
  wavView.setUint32(40, dataSize, true); // Subchunk2Size

  // Write PCM data
  const pcmBytes = new Uint8Array(buffer);
  const wavBytes = new Uint8Array(wavBuffer);
  wavBytes.set(new Uint8Array(wavBuffer.slice(0, 44)), 0);
  wavBytes.set(pcmBytes, 44);

  return new Blob([wavBytes], { type: 'audio/wav' });
};

export const generateSpeech = async (text: string): Promise<Blob> => {
  try {
    const ai = getAiClient();
    // Truncate text if too long to avoid token limits for demo
    const safeText = text.slice(0, 4000); 
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: { parts: [{ text: safeText }] },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error("No audio data received");
    }

    return createWavFile(base64Audio, 24000);
  } catch (error) {
    console.error("AI Speech Generation Error:", error);
    throw error;
  }
};