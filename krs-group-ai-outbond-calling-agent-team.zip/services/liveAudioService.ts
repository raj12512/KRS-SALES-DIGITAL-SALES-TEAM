
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";

// Audio Configuration
const INPUT_SAMPLE_RATE = 16000;
const OUTPUT_SAMPLE_RATE = 24000;
const BUFFER_SIZE = 4096;

export class LiveAudioService {
  private session: Promise<any> | null = null;
  private inputContext: AudioContext | null = null;
  private outputContext: AudioContext | null = null;
  
  // Nodes
  private inputSource: MediaStreamAudioSourceNode | null = null;
  private processor: ScriptProcessorNode | null = null;
  private stream: MediaStream | null = null;
  
  // Recording & Mixing
  private recordingDestination: MediaStreamAudioDestinationNode | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  
  // Analysis
  private analyser: AnalyserNode | null = null;
  private volumeCallback: ((volume: number) => void) | null = null;

  private nextStartTime: number = 0;
  private isConnected: boolean = false;
  private onStatusChange: (status: string) => void;

  constructor(onStatusChange: (status: string) => void, onVolumeChange?: (vol: number) => void) {
    this.onStatusChange = onStatusChange;
    this.volumeCallback = onVolumeChange || null;
  }

  /**
   * Connects to the Gemini Live API.
   * @param systemInstruction - The persona/instructions for the AI.
   * @param voiceName - Optional voice name (Puck, Charon, Kore, Fenrir, Zephyr).
   */
  async connect(systemInstruction: string, voiceName: string = 'Puck') {
    if (this.isConnected) await this.disconnect();

    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.error("API Key is missing in process.env");
      this.onStatusChange("error");
      return;
    }

    try {
      this.onStatusChange("connecting");
      
      // Initialize Audio Contexts
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.inputContext = new AudioContextClass({ sampleRate: INPUT_SAMPLE_RATE });
      this.outputContext = new AudioContextClass({ sampleRate: OUTPUT_SAMPLE_RATE });

      // Setup Mixing for Recording
      // We need a destination to mix Mic + AI Output
      this.recordingDestination = this.outputContext.createMediaStreamDestination();
      
      // Setup Analyser for Visuals
      this.analyser = this.outputContext.createAnalyser();
      this.analyser.fftSize = 256;
      this.startVolumeAnalysis();

      // Get Microphone Stream
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      // Instantiate AI Client
      const ai = new GoogleGenAI({ apiKey });

      // Connect to Gemini Live
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: voiceName } },
          },
          systemInstruction: systemInstruction,
        },
        callbacks: {
          onopen: async () => {
            console.log("Gemini Live Session Opened");
            this.isConnected = true;
            this.onStatusChange("connected");
            await this.startAudioInput(sessionPromise);
            this.startRecording();
          },
          onmessage: (message: LiveServerMessage) => this.handleMessage(message),
          onclose: () => {
            console.log("Gemini Live Session Closed");
            this.onStatusChange("disconnected");
            this.cleanup();
          },
          onerror: (err) => {
            console.error("Gemini Live API Error:", err);
            this.onStatusChange("error");
            this.cleanup();
          }
        }
      });

      this.session = sessionPromise;
      
      sessionPromise.catch(err => {
        console.error("Session connection failed:", err);
        this.onStatusChange("error");
        this.cleanup();
      });

    } catch (error) {
      console.error("Connection setup failed:", error);
      this.onStatusChange("error");
      this.cleanup();
    }
  }

  private async startAudioInput(sessionPromise: Promise<any>) {
    if (!this.inputContext || !this.stream) return;

    if (this.inputContext.state === 'suspended') await this.inputContext.resume();
    
    this.inputSource = this.inputContext.createMediaStreamSource(this.stream);
    this.processor = this.inputContext.createScriptProcessor(BUFFER_SIZE, 1, 1);

    this.processor.onaudioprocess = (e) => {
      if (!this.isConnected) return;

      const inputData = e.inputBuffer.getChannelData(0);
      const pcmData = this.floatTo16BitPCM(inputData);
      const base64Data = this.arrayBufferToBase64(pcmData);

      sessionPromise.then(session => {
        try {
          session.sendRealtimeInput({
            media: {
              mimeType: "audio/pcm;rate=16000",
              data: base64Data
            }
          });
        } catch (err) {
            // Ignore send errors if closing
        }
      }).catch(err => {});
    };

    this.inputSource.connect(this.processor);
    this.processor.connect(this.inputContext.destination);

    // Also connect Mic to Recording Destination (but NOT to speakers to avoid feedback)
    // We need to cross-connect from inputContext to outputContext for mixing if strictly needed,
    // but simpler to just record input separately or clone tracks. 
    // However, connecting MediaStreamAudioSourceNode from one context to a destination in another is tricky.
    // Hack: We rely on the fact that we can reuse the `stream` in the output context for recording purposes.
    if (this.outputContext && this.recordingDestination) {
        const micNodeForRecord = this.outputContext.createMediaStreamSource(this.stream);
        micNodeForRecord.connect(this.recordingDestination);
        // Also connect to analyser for visualizer (Mic Volume)
        if (this.analyser) micNodeForRecord.connect(this.analyser);
    }
  }

  private startRecording() {
    if (!this.recordingDestination) return;
    
    this.recordedChunks = [];
    // Record the mixed stream (Mic + AI)
    this.mediaRecorder = new MediaRecorder(this.recordingDestination.stream);
    
    this.mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) {
        this.recordedChunks.push(e.data);
      }
    };
    
    this.mediaRecorder.start();
  }

  public async getRecording(): Promise<Blob | null> {
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
        this.mediaRecorder.stop();
        // Give it a moment to finalize
        await new Promise(resolve => setTimeout(resolve, 200));
    }
    if (this.recordedChunks.length === 0) return null;
    return new Blob(this.recordedChunks, { type: 'audio/webm' });
  }

  public toggleMute(isMuted: boolean) {
    if (this.stream) {
        this.stream.getAudioTracks().forEach(track => {
            track.enabled = !isMuted;
        });
    }
  }

  private startVolumeAnalysis() {
    const update = () => {
        if (!this.isConnected || !this.analyser) return;
        
        const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
        this.analyser.getByteFrequencyData(dataArray);
        
        // Calculate average volume
        let sum = 0;
        for (const amplitude of dataArray) {
            sum += amplitude;
        }
        const volume = sum / dataArray.length; // 0 - 255
        
        if (this.volumeCallback) {
            this.volumeCallback(volume);
        }
        
        requestAnimationFrame(update);
    };
    update();
  }

  private async handleMessage(message: LiveServerMessage) {
    const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
    
    if (base64Audio && this.outputContext) {
      try {
        if (this.outputContext.state === 'suspended') await this.outputContext.resume();
        
        const audioData = this.base64ToArrayBuffer(base64Audio);
        const audioBuffer = await this.decodeAudioData(audioData);
        this.playAudioBuffer(audioBuffer);
      } catch (e) {
        console.error("Error processing audio message:", e);
      }
    }

    if (message.serverContent?.interrupted) {
        this.nextStartTime = 0;
    }
  }

  private playAudioBuffer(buffer: AudioBuffer) {
    if (!this.outputContext) return;

    const source = this.outputContext.createBufferSource();
    source.buffer = buffer;
    
    // Connect AI Audio to Speakers
    source.connect(this.outputContext.destination);
    
    // Connect AI Audio to Recording Destination
    if (this.recordingDestination) {
        source.connect(this.recordingDestination);
    }

    // Connect AI Audio to Analyser (Visualizer)
    if (this.analyser) {
        source.connect(this.analyser);
    }

    const currentTime = this.outputContext.currentTime;
    const startTime = Math.max(currentTime, this.nextStartTime);
    
    source.start(startTime);
    this.nextStartTime = startTime + buffer.duration;
  }

  async disconnect() {
    this.onStatusChange("disconnecting");
    
    // Stop Recorder
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
        this.mediaRecorder.stop();
    }

    if (this.session) {
      try {
        const s = await this.session;
        if (s && typeof s.close === 'function') {
            s.close();
        }
      } catch (e) {}
    }
    this.cleanup();
  }

  private cleanup() {
    this.isConnected = false;
    this.nextStartTime = 0;
    this.session = null;

    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    
    if (this.inputSource) {
      this.inputSource.disconnect();
      this.inputSource = null;
    }
    
    if (this.inputContext && this.inputContext.state !== 'closed') {
      this.inputContext.close();
    }
    this.inputContext = null;

    if (this.outputContext && this.outputContext.state !== 'closed') {
      this.outputContext.close();
    }
    this.outputContext = null;
  }

  private floatTo16BitPCM(input: Float32Array): ArrayBuffer {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    return output.buffer;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }

  private async decodeAudioData(data: ArrayBuffer): Promise<AudioBuffer> {
    if (!this.outputContext) throw new Error("No output context");
    const dataInt16 = new Int16Array(data);
    const float32 = new Float32Array(dataInt16.length);
    for (let i = 0; i < dataInt16.length; i++) {
      float32[i] = dataInt16[i] / 32768.0;
    }
    const buffer = this.outputContext.createBuffer(1, float32.length, OUTPUT_SAMPLE_RATE);
    buffer.copyToChannel(float32, 0);
    return buffer;
  }
}
