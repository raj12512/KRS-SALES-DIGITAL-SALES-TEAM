import { Lead, LeadFormData, StorageService } from '../types';

const STORAGE_KEY = 'property_leads_db_v1';

// Simulate Backend/DB latency
const LATENCY_MS = 300;
const delay = () => new Promise(resolve => setTimeout(resolve, LATENCY_MS));

const getStoredData = (): Lead[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored ? JSON.parse(stored) : [];
};

const setStoredData = (data: Lead[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

export const storageService: StorageService = {
  getLeads: async (): Promise<Lead[]> => {
    await delay();
    return getStoredData().sort((a, b) => b.createdAt - a.createdAt);
  },

  saveLead: async (data: LeadFormData): Promise<Lead> => {
    await delay();
    const leads = getStoredData();
    const newLead: Lead = {
      ...data,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
      callHistory: []
    };
    setStoredData([...leads, newLead]);
    return newLead;
  },

  saveLeads: async (dataList: LeadFormData[]): Promise<Lead[]> => {
    await delay();
    const leads = getStoredData();
    const newLeads: Lead[] = dataList.map(data => ({
      ...data,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
      callHistory: []
    }));
    setStoredData([...leads, ...newLeads]);
    return newLeads;
  },

  updateLead: async (id: string, data: Partial<Lead>): Promise<Lead> => {
    await delay();
    const leads = getStoredData();
    const index = leads.findIndex(c => c.id === id);
    if (index === -1) throw new Error('Lead not found');
    
    // Merge existing lead with updates
    const updatedLead = { ...leads[index], ...data };
    leads[index] = updatedLead;
    setStoredData(leads);
    return updatedLead;
  },

  deleteLead: async (id: string): Promise<void> => {
    await delay();
    const leads = getStoredData();
    const filtered = leads.filter(c => c.id !== id);
    setStoredData(filtered);
  }
};