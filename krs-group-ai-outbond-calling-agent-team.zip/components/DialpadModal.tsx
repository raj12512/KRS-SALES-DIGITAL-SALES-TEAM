import React, { useState } from 'react';
import { X, Phone, User, MapPin, Building, Loader2 } from 'lucide-react';
import { Lead } from '../types';

interface DialpadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCall: (tempLead: Lead) => void;
}

export const DialpadModal: React.FC<DialpadModalProps> = ({ isOpen, onClose, onCall }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    city: '',
    propertyType: 'House'
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create a temporary lead object
    const tempLead: Lead = {
        id: 'temp-' + Date.now(),
        name: formData.name || 'Unknown Lead',
        phone: formData.phone || '000-000-0000',
        city: formData.city || 'Unknown City',
        propertyType: formData.propertyType as any,
        createdAt: Date.now()
    };

    onCall(tempLead);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-xs overflow-hidden border border-slate-100">
        <div className="px-5 py-3 border-b border-gray-100 flex justify-between items-center bg-slate-900 text-white">
          <h2 className="text-base font-bold flex items-center gap-2">
            <Phone size={16} className="text-green-400" />
            Direct Dial
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-700 transition-colors">
            <X size={16} className="text-slate-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-3">
          <div className="relative">
            <div className="absolute left-3 top-2.5 text-slate-400 pointer-events-none">
                <Phone size={16} />
            </div>
            <input 
              type="tel" 
              required
              autoFocus
              placeholder="Phone Number"
              value={formData.phone}
              onChange={e => setFormData({...formData, phone: e.target.value})}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-lg font-mono text-slate-800 placeholder-slate-400"
            />
          </div>

          <div className="relative">
            <div className="absolute left-3 top-2.5 text-slate-400 pointer-events-none">
                <User size={16} />
            </div>
            <input 
              type="text" 
              placeholder="Lead Name (Optional)"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="relative">
                <div className="absolute left-2.5 top-2.5 text-slate-400 pointer-events-none">
                    <MapPin size={14} />
                </div>
                <input 
                type="text" 
                placeholder="City"
                value={formData.city}
                onChange={e => setFormData({...formData, city: e.target.value})}
                className="w-full pl-8 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-xs"
                />
            </div>
             <div className="relative">
                <div className="absolute left-2.5 top-2.5 text-slate-400 pointer-events-none">
                    <Building size={14} />
                </div>
                <select 
                    value={formData.propertyType}
                    onChange={e => setFormData({...formData, propertyType: e.target.value})}
                    className="w-full pl-8 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-xs appearance-none bg-white"
                >
                    <option>House</option>
                    <option>Apartment</option>
                    <option>Land</option>
                    <option>Commercial</option>
                </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-bold shadow-lg shadow-green-200 flex items-center justify-center gap-2 transition-all hover:-translate-y-0.5 mt-2"
          >
            <Phone size={18} fill="currentColor" />
            Call Now
          </button>
        </form>
      </div>
    </div>
  );
};