import React, { useState } from 'react';
import { X, Calendar, Clock } from 'lucide-react';

interface ScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSchedule: (timestamp: number) => void;
}

export const ScheduleModal: React.FC<ScheduleModalProps> = ({ isOpen, onClose, onSchedule }) => {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !time) return;
    
    const timestamp = new Date(`${date}T${time}`).getTime();
    if (isNaN(timestamp)) return;

    onSchedule(timestamp);
    onClose();
  };

  // Helper to set time to 1 min from now for quick demo
  const setQuickDemo = () => {
    const now = new Date();
    const oneMinFromNow = new Date(now.getTime() + 60000);
    
    // Format YYYY-MM-DD
    const dateStr = oneMinFromNow.toISOString().split('T')[0];
    // Format HH:MM
    const timeStr = oneMinFromNow.toTimeString().substring(0, 5);

    setDate(dateStr);
    setTime(timeStr);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden border border-slate-100">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-slate-50">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Clock size={18} className="text-blue-600" />
            Schedule Call
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 transition-colors">
            <X size={18} className="text-slate-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Date</label>
            <input 
              type="date" 
              required
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Time</label>
            <input 
              type="time" 
              required
              value={time}
              onChange={e => setTime(e.target.value)}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
            />
          </div>
          
          <button 
            type="button"
            onClick={setQuickDemo}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium hover:underline"
          >
            Set to 1 minute from now (Test)
          </button>

          <button
            type="submit"
            className="w-full py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors shadow-sm"
          >
            Confirm Schedule
          </button>
        </form>
      </div>
    </div>
  );
};