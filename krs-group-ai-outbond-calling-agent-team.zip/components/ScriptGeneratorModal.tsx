import React, { useState, useEffect } from 'react';
import { generateScript, generateSpeech } from '../services/geminiService';
import { X, Mic, Loader2, Copy, Check, FileText, Download, Volume2, MessageSquareText, Sparkles } from 'lucide-react';

interface ScriptGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PROPERTY_TYPES = ['House', 'Apartment', 'Condo', 'Commercial', 'Land', 'Other'];

export const ScriptGeneratorModal: React.FC<ScriptGeneratorModalProps> = ({ 
  isOpen, 
  onClose 
}) => {
  const [activeTab, setActiveTab] = useState<'generator' | 'tts'>('generator');

  // Generator State
  const [city, setCity] = useState('');
  const [budget, setBudget] = useState('');
  const [propertyType, setPropertyType] = useState('House');
  const [generatedScript, setGeneratedScript] = useState('');
  
  // TTS State
  const [ttsText, setTtsText] = useState('');
  
  // Shared State
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  // Reset state when opening/closing or switching tabs
  useEffect(() => {
    if (isOpen) {
      setAudioUrl(null);
    }
  }, [isOpen]);

  const handleTabChange = (tab: 'generator' | 'tts') => {
    setActiveTab(tab);
    setAudioUrl(null);
    // If switching to TTS and we have a generated script, pre-fill it
    if (tab === 'tts' && generatedScript && !ttsText) {
      setTtsText(generatedScript);
    }
  };

  const handleGenerateScript = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!city || !budget) return;
    
    setIsLoading(true);
    setGeneratedScript('');
    setAudioUrl(null);
    try {
      const script = await generateScript(city, budget, propertyType);
      setGeneratedScript(script);
      setTtsText(script); // Also update TTS text for convenience
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(activeTab === 'generator' ? generatedScript : ttsText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleGenerateAudio = async () => {
    const textToSpeak = activeTab === 'generator' ? generatedScript : ttsText;
    
    if (!textToSpeak || isGeneratingAudio) return;
    
    setIsGeneratingAudio(true);
    setAudioUrl(null);
    try {
      // Clean up text for better speech (remove some formatting characters)
      const cleanText = textToSpeak.replace(/[*#]/g, '');
      const blob = await generateSpeech(cleanText);
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
    } catch (error) {
      alert("Failed to generate audio. Please try again.");
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl overflow-hidden flex flex-col max-h-[90vh] border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-slate-50 shrink-0">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <Sparkles size={20} className="text-blue-600" />
            AI Content Tools
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 transition-colors">
            <X size={20} className="text-slate-500" />
          </button>
        </div>

        <div className="flex flex-col md:flex-row h-full overflow-hidden">
          {/* Left Sidebar - Controls */}
          <div className="md:w-[320px] bg-white border-b md:border-b-0 md:border-r border-gray-100 shrink-0 flex flex-col">
            
            {/* Tabs */}
            <div className="flex p-2 gap-1 border-b border-gray-100">
              <button
                onClick={() => handleTabChange('generator')}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2 ${
                  activeTab === 'generator' 
                    ? 'bg-blue-50 text-blue-700 shadow-sm' 
                    : 'text-slate-500 hover:bg-slate-50'
                }`}
              >
                <FileText size={16} />
                Script Gen
              </button>
              <button
                onClick={() => handleTabChange('tts')}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2 ${
                  activeTab === 'tts' 
                    ? 'bg-blue-50 text-blue-700 shadow-sm' 
                    : 'text-slate-500 hover:bg-slate-50'
                }`}
              >
                <Volume2 size={16} />
                Text to Speech
              </button>
            </div>

            <div className="p-6 overflow-y-auto">
              {activeTab === 'generator' ? (
                <form onSubmit={handleGenerateScript} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Target City</label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
                      placeholder="e.g. Miami"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Buyer Budget</label>
                    <input
                      type="text"
                      required
                      value={budget}
                      onChange={(e) => setBudget(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
                      placeholder="e.g. $500k - $600k"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Property Type</label>
                    <select
                      value={propertyType}
                      onChange={(e) => setPropertyType(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
                    >
                      {PROPERTY_TYPES.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-all shadow-md shadow-blue-200 mt-2"
                  >
                    {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
                    Generate Script
                  </button>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-100 text-xs text-blue-700">
                    Enter any text below to convert it into a professional voiceover audio file.
                  </div>
                  <button
                    onClick={handleGenerateAudio}
                    disabled={isGeneratingAudio || !ttsText}
                    className="w-full py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-all shadow-md shadow-blue-200"
                  >
                    {isGeneratingAudio ? <Loader2 size={18} className="animate-spin" /> : <Volume2 size={18} />}
                    Generate Audio
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Right Panel - Output */}
          <div className="flex-1 bg-slate-50 p-6 overflow-y-auto relative min-h-[300px] flex flex-col">
            
            {/* Audio Player Section */}
            {audioUrl && (
              <div className="mb-6 p-4 bg-white rounded-xl border border-slate-200 shadow-sm animate-in slide-in-from-top-4">
                <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <Check size={14} className="text-green-500" />
                        Audio Generated
                    </h3>
                    <a 
                      href={audioUrl} 
                      download="property-script.wav"
                      className="text-xs font-medium text-blue-600 hover:underline flex items-center gap-1"
                    >
                      <Download size={14} /> Download WAV
                    </a>
                </div>
                <audio controls src={audioUrl} className="w-full h-10" />
              </div>
            )}

            {/* Content Display */}
            {activeTab === 'generator' ? (
                generatedScript ? (
                  <div className="animate-in fade-in duration-500 flex-1 flex flex-col">
                    <div className="flex justify-between items-center mb-4 sticky top-0 bg-slate-50 pt-1 pb-2 z-10">
                      <h3 className="font-semibold text-slate-700">Generated Script</h3>
                      <div className="flex gap-2">
                        <button
                            onClick={handleGenerateAudio}
                            disabled={isGeneratingAudio}
                            className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 bg-white border border-slate-200 rounded-md hover:bg-slate-100 text-slate-600 transition-colors shadow-sm disabled:opacity-50"
                        >
                            {isGeneratingAudio ? <Loader2 size={14} className="animate-spin" /> : <Volume2 size={14} />}
                            Listen
                        </button>
                        <button 
                          onClick={handleCopy}
                          className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 bg-white border border-slate-200 rounded-md hover:bg-slate-100 text-slate-600 transition-colors shadow-sm"
                        >
                          {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                          Copy
                        </button>
                      </div>
                    </div>
                    <div className="prose prose-sm prose-slate max-w-none bg-white p-6 rounded-xl border border-slate-200 shadow-sm whitespace-pre-wrap font-sans text-slate-700 flex-1">
                      {generatedScript}
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400">
                    {isLoading ? (
                      <div className="text-center space-y-3">
                        <Loader2 size={32} className="animate-spin text-blue-500 mx-auto" />
                        <p className="text-sm font-medium text-slate-500">Writing professional script...</p>
                      </div>
                    ) : (
                      <>
                        <FileText size={48} className="mb-4 opacity-20" />
                        <p className="text-sm">Enter details in the sidebar to generate a call script.</p>
                      </>
                    )}
                  </div>
                )
            ) : (
                /* TTS Input Area */
                <div className="flex-1 flex flex-col animate-in fade-in">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="font-semibold text-slate-700">Script Text</h3>
                        <button 
                          onClick={handleCopy}
                          className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 bg-white border border-slate-200 rounded-md hover:bg-slate-100 text-slate-600 transition-colors shadow-sm"
                        >
                          {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                          Copy Text
                        </button>
                    </div>
                    <textarea
                        value={ttsText}
                        onChange={(e) => setTtsText(e.target.value)}
                        placeholder="Paste your script here or type something to convert to speech..."
                        className="flex-1 w-full p-6 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm font-sans leading-relaxed shadow-sm outline-none"
                    />
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};