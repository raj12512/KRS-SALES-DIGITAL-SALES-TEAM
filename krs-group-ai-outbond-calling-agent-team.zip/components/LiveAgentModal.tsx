import React, { useState, useEffect, useRef } from 'react';
import { X, Mic, MicOff, Activity, Bot, User, Volume2, StopCircle } from 'lucide-react';
import { LiveAudioService } from '../services/liveAudioService';

interface LiveAgentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PERSONAS = [
  {
    id: 'first_time_buyer',
    name: 'First-Time Buyer',
    description: 'Nervous, asks basic questions, budget sensitive.',
    instruction: 'You are a first-time home buyer named Sarah. You are nervous, budget-conscious ($400k max), and ask a lot of basic questions about the buying process. You are currently renting. Keep responses concise.'
  },
  {
    id: 'investor',
    name: 'Aggressive Investor',
    description: 'Direct, focused on ROI, cash buyer.',
    instruction: 'You are a real estate investor named Mike. You are direct, aggressive, and only care about ROI and Cap Rate. You are a cash buyer looking for distressed properties. You are impatient.'
  },
  {
    id: 'angry_seller',
    name: 'Frustrated Seller',
    description: 'Expired listing, distrustful of agents.',
    instruction: 'You are a homeowner named Gary. Your house was on the market for 6 months and did not sell. You are angry at real estate agents and distrustful. You think your house is worth way more than it is.'
  }
];

export const LiveAgentModal: React.FC<LiveAgentModalProps> = ({ isOpen, onClose }) => {
  const [status, setStatus] = useState<string>('disconnected');
  const [selectedPersonaId, setSelectedPersonaId] = useState(PERSONAS[0].id);
  const liveServiceRef = useRef<LiveAudioService | null>(null);

  useEffect(() => {
    // Cleanup on unmount or close
    return () => {
      if (liveServiceRef.current) {
        liveServiceRef.current.disconnect();
      }
    };
  }, []);

  useEffect(() => {
    if (!isOpen && liveServiceRef.current) {
        liveServiceRef.current.disconnect();
    }
  }, [isOpen]);

  const handleToggleConnection = async () => {
    if (status === 'connected' || status === 'connecting') {
      liveServiceRef.current?.disconnect();
    } else {
      const persona = PERSONAS.find(p => p.id === selectedPersonaId);
      if (!persona) return;

      liveServiceRef.current = new LiveAudioService((s) => setStatus(s));
      await liveServiceRef.current.connect(persona.instruction);
    }
  };

  if (!isOpen) return null;

  const currentPersona = PERSONAS.find(p => p.id === selectedPersonaId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col relative animate-in zoom-in-50 duration-300 border border-slate-700">
        
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-gray-100">
            <div>
                <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <Bot size={24} className="text-purple-600" />
                    Roleplay Partner
                </h2>
                <p className="text-sm text-slate-500">Practice your scripts with AI.</p>
            </div>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 transition-colors">
                <X size={20} className="text-slate-500" />
            </button>
        </div>

        {/* Content */}
        <div className="p-8 flex flex-col items-center gap-8 bg-slate-50">
            
            {/* Visualizer / Avatar */}
            <div className="relative">
                <div className={`w-32 h-32 rounded-full flex items-center justify-center transition-all duration-500 ${
                    status === 'connected' 
                        ? 'bg-purple-100 border-4 border-purple-500 shadow-[0_0_30px_rgba(168,85,247,0.4)]' 
                        : 'bg-gray-200 border-4 border-gray-300'
                }`}>
                    <Bot size={48} className={`transition-colors ${status === 'connected' ? 'text-purple-600' : 'text-gray-400'}`} />
                </div>
                
                {status === 'connected' && (
                    <div className="absolute -bottom-2 -right-2 bg-green-500 text-white p-2 rounded-full border-2 border-white">
                        <Volume2 size={16} className="animate-pulse" />
                    </div>
                )}
            </div>

            {/* Status Text */}
            <div className="text-center space-y-1">
                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide ${
                    status === 'connected' ? 'bg-green-100 text-green-700' : 
                    status === 'connecting' ? 'bg-yellow-100 text-yellow-700' : 
                    status === 'error' ? 'bg-red-100 text-red-700' :
                    'bg-gray-100 text-gray-500'
                }`}>
                    <div className={`w-2 h-2 rounded-full ${
                        status === 'connected' ? 'bg-green-500 animate-pulse' : 
                        status === 'connecting' ? 'bg-yellow-500 animate-bounce' : 
                        status === 'error' ? 'bg-red-500' :
                        'bg-gray-400'
                    }`}></div>
                    {status}
                </div>
                {status === 'connected' && (
                    <p className="text-sm text-slate-500">Listening to your microphone...</p>
                )}
            </div>

            {/* Persona Selector (Only when disconnected) */}
            {status === 'disconnected' && (
                <div className="w-full space-y-3">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Select Roleplay Persona</label>
                    <div className="grid grid-cols-1 gap-2">
                        {PERSONAS.map(p => (
                            <button
                                key={p.id}
                                onClick={() => setSelectedPersonaId(p.id)}
                                className={`flex items-start gap-3 p-3 rounded-xl border text-left transition-all ${
                                    selectedPersonaId === p.id 
                                        ? 'bg-purple-50 border-purple-300 ring-1 ring-purple-300 shadow-sm' 
                                        : 'bg-white border-gray-200 hover:border-purple-200 hover:bg-gray-50'
                                }`}
                            >
                                <div className={`mt-0.5 p-1.5 rounded-lg ${selectedPersonaId === p.id ? 'bg-purple-200' : 'bg-gray-100'}`}>
                                    <User size={16} className={selectedPersonaId === p.id ? 'text-purple-700' : 'text-gray-500'} />
                                </div>
                                <div>
                                    <h4 className={`text-sm font-semibold ${selectedPersonaId === p.id ? 'text-purple-900' : 'text-slate-700'}`}>{p.name}</h4>
                                    <p className="text-xs text-slate-500 mt-0.5">{p.description}</p>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>

        {/* Footer Controls */}
        <div className="p-6 bg-white border-t border-gray-100 flex flex-col gap-3">
            <button
                onClick={handleToggleConnection}
                disabled={status === 'connecting'}
                className={`w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 active:shadow-md ${
                    status === 'connected' 
                        ? 'bg-red-500 text-white hover:bg-red-600 shadow-red-200' 
                        : 'bg-purple-600 text-white hover:bg-purple-700 shadow-purple-200'
                }`}
            >
                {status === 'connected' ? (
                    <>
                        <StopCircle size={24} /> End Session
                    </>
                ) : status === 'connecting' ? (
                    <>
                        <Activity size={24} className="animate-spin" /> Connecting...
                    </>
                ) : (
                    <>
                        <Mic size={24} /> Start Conversation
                    </>
                )}
            </button>
            <p className="text-xs text-center text-slate-400">
                Use headphones for best experience. <br/> This uses your browser's microphone.
            </p>
        </div>

      </div>
    </div>
  );
};