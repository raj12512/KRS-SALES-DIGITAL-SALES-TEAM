import React, { useEffect, useRef, useState } from 'react';
import { Lead } from '../types';
import { LiveAudioService } from '../services/liveAudioService';
import { Phone, PhoneOff, User, CheckCircle, XCircle, Clock, Loader2, Mic, MicOff, Activity, Download, Save, MessageSquare } from 'lucide-react';

interface ActiveCallModalProps {
  lead: Lead;
  onComplete: (status: 'Interested' | 'Not Interested' | 'Call Later', notes?: string, recordingUrl?: string) => void;
}

export const ActiveCallModal: React.FC<ActiveCallModalProps> = ({ lead, onComplete }) => {
  const [status, setStatus] = useState<'connecting' | 'connected' | 'ended'>('connecting');
  const [volume, setVolume] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [showDispositionForm, setShowDispositionForm] = useState(false);
  const [disposition, setDisposition] = useState<'Interested' | 'Not Interested' | 'Call Later' | null>(null);
  const [notes, setNotes] = useState('');
  const [recordingUrl, setRecordingUrl] = useState<string | null>(null);
  
  const liveServiceRef = useRef<LiveAudioService | null>(null);

  useEffect(() => {
    // Initialize Service with volume callback
    liveServiceRef.current = new LiveAudioService(
        (s) => {
            if (s === 'connected') setStatus('connected');
            if (s === 'disconnected' || s === 'error') {
                if (status !== 'ended') setStatus('ended');
            }
        },
        (vol) => setVolume(vol) // Update volume state for visualizer
    );

    startCall();

    return () => {
        liveServiceRef.current?.disconnect();
    };
  }, []);

  const startCall = async () => {
    const systemPrompt = `
      You are a real estate lead named ${lead.name}.
      You live in ${lead.city}.
      You are interested in a ${lead.propertyType}.
      You are answering a cold call from a real estate agent.
      
      Instructions:
      1. Answer the phone naturally (e.g., "Hello?", "This is ${lead.name}").
      2. Act realistically based on the property type.
      3. Your goal is to see if the agent provides value.
      4. Keep responses concise (spoken conversation style).
    `;

    try {
        await liveServiceRef.current?.connect(systemPrompt, 'Puck');
    } catch (e) {
        console.error("Call failed", e);
        setStatus('ended');
    }
  };

  const toggleMute = () => {
      const newMuteState = !isMuted;
      setIsMuted(newMuteState);
      liveServiceRef.current?.toggleMute(newMuteState);
  };

  const handleHangup = async () => {
    // Get recording before full disconnect
    const blob = await liveServiceRef.current?.getRecording();
    if (blob) {
        const url = URL.createObjectURL(blob);
        setRecordingUrl(url);
    }

    liveServiceRef.current?.disconnect();
    setStatus('ended');
  };

  const handleDispositionClick = (result: 'Interested' | 'Not Interested' | 'Call Later') => {
      setDisposition(result);
      setShowDispositionForm(true);
      // Don't hang up yet, allow user to finish notes while call might technically be open, or hang up automatically?
      // Better to hang up audio but keep modal open for notes.
      handleHangup();
  };

  const submitDisposition = () => {
      if (disposition) {
          onComplete(disposition, notes, recordingUrl || undefined);
      }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-md">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden flex flex-col relative animate-in zoom-in-50 duration-300">
        
        {/* Call Header / Visualizer */}
        <div className="bg-slate-900 h-64 flex flex-col items-center justify-center text-white relative p-6 overflow-hidden transition-all">
          {/* Background Animation */}
          <div className="absolute inset-0 bg-gradient-to-b from-slate-800 to-slate-900"></div>
          
          {/* Dynamic Visualizer Background */}
          {status === 'connected' && (
              <div 
                className="absolute inset-0 flex items-center justify-center opacity-30 transition-all duration-75"
                style={{ transform: `scale(${1 + (volume / 100)})` }}
              >
                  <div className="w-48 h-48 bg-blue-500 rounded-full blur-3xl"></div>
              </div>
          )}
          
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-24 h-24 bg-slate-800 rounded-full flex items-center justify-center mb-4 relative ring-4 ring-slate-800">
                <User size={40} className="text-slate-400" />
                {status === 'connected' && (
                  <span className="absolute inset-0 border-4 border-green-500/50 rounded-full animate-ping"></span>
                )}
            </div>
            
            <h2 className="text-2xl font-bold">{lead.name}</h2>
            
            {/* Real-time Status */}
            <div className="flex items-center gap-2 mt-2 h-6">
                {status === 'connecting' && <Loader2 size={14} className="animate-spin text-amber-400" />}
                {status === 'connected' && (
                    <>
                        {volume > 10 ? (
                            <div className="flex items-center gap-1">
                                <Activity size={14} className="text-blue-400" />
                                <span className="text-blue-400 text-xs font-bold uppercase">Speaking...</span>
                            </div>
                        ) : (
                            <div className="flex items-center gap-1">
                                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                                <span className="text-green-400 text-xs font-bold uppercase">Connected</span>
                            </div>
                        )}
                        <span className="text-slate-600 text-xs">|</span>
                        <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" title="Recording"></div>
                        <span className="text-red-400 text-xs">REC</span>
                    </>
                )}
                {status === 'ended' && <span className="text-red-400 text-sm font-bold">Call Ended</span>}
            </div>
            <p className="text-slate-500 text-xs mt-1">{lead.phone}</p>
          </div>
        </div>

        {/* Controls */}
        <div className="p-6 bg-slate-50 flex-1">
          {showDispositionForm ? (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
                  <div className="text-center">
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase mb-2 ${
                          disposition === 'Interested' ? 'bg-green-100 text-green-700' :
                          disposition === 'Not Interested' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                          {disposition}
                      </div>
                      <h3 className="text-lg font-bold text-slate-800">Add Call Notes</h3>
                  </div>
                  
                  <div className="relative">
                    <MessageSquare size={16} className="absolute left-3 top-3 text-slate-400" />
                    <textarea 
                        autoFocus
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Key takeaways, objections, or follow-up details..."
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm min-h-[100px] resize-none"
                    />
                  </div>

                  {recordingUrl && (
                      <a 
                        href={recordingUrl} 
                        download={`call-${lead.name}-${Date.now()}.webm`}
                        className="flex items-center justify-center gap-2 w-full py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-medium transition-colors"
                      >
                          <Download size={14} /> Download Recording
                      </a>
                  )}

                  <button 
                    onClick={submitDisposition}
                    className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-lg flex items-center justify-center gap-2"
                  >
                      <Save size={18} /> Save & Close
                  </button>
              </div>
          ) : (
            status === 'connected' || status === 'connecting' ? (
                <div className="space-y-8">
                
                {/* Mute Control */}
                <div className="flex justify-center">
                    <button 
                        onClick={toggleMute}
                        className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                            isMuted ? 'bg-red-100 text-red-600 ring-2 ring-red-200' : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                        }`}
                    >
                        {isMuted ? <MicOff size={16} /> : <Mic size={16} />}
                        {isMuted ? 'Muted' : 'Mute Mic'}
                    </button>
                </div>

                <div className="flex justify-center">
                        <button 
                            onClick={handleHangup}
                            className="w-16 h-16 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center text-white shadow-xl shadow-red-200 transition-transform hover:scale-105 active:scale-95"
                        >
                            <PhoneOff size={28} />
                        </button>
                </div>
                </div>
            ) : (
                <div className="space-y-4">
                    <p className="text-center text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Log Call Outcome</p>
                    <div className="grid grid-cols-3 gap-3">
                    <button 
                        onClick={() => handleDispositionClick('Interested')}
                        className="flex flex-col items-center gap-2 p-3 bg-white border border-green-200 rounded-xl hover:bg-green-50 hover:border-green-300 transition-all shadow-sm group"
                    >
                        <div className="p-2 bg-green-100 text-green-600 rounded-full group-hover:scale-110 transition-transform">
                            <CheckCircle size={20} />
                        </div>
                        <span className="text-xs font-semibold text-slate-700">Interested</span>
                    </button>

                    <button 
                        onClick={() => handleDispositionClick('Call Later')}
                        className="flex flex-col items-center gap-2 p-3 bg-white border border-amber-200 rounded-xl hover:bg-amber-50 hover:border-amber-300 transition-all shadow-sm group"
                    >
                        <div className="p-2 bg-amber-100 text-amber-600 rounded-full group-hover:scale-110 transition-transform">
                            <Clock size={20} />
                        </div>
                        <span className="text-xs font-semibold text-slate-700">Call Later</span>
                    </button>

                    <button 
                        onClick={() => handleDispositionClick('Not Interested')}
                        className="flex flex-col items-center gap-2 p-3 bg-white border border-red-200 rounded-xl hover:bg-red-50 hover:border-red-300 transition-all shadow-sm group"
                    >
                        <div className="p-2 bg-red-100 text-red-600 rounded-full group-hover:scale-110 transition-transform">
                            <XCircle size={20} />
                        </div>
                        <span className="text-xs font-semibold text-slate-700">Not Fit</span>
                    </button>
                </div>

                {recordingUrl && (
                    <div className="pt-2">
                        <a 
                            href={recordingUrl} 
                            download={`call-${lead.name}.webm`}
                            className="flex items-center justify-center gap-2 w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-medium transition-colors"
                        >
                            <Download size={14} /> Download Recording
                        </a>
                    </div>
                )}
                </div>
            )
          )}
        </div>

      </div>
    </div>
  );
};