import React, { useState, useEffect } from 'react';
import { X, Settings, Smartphone, Save, Key, Globe, Check, Loader2, Info } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const [provider, setProvider] = useState<'simulation' | 'twilio' | 'vapi'>('simulation');
  
  // Twilio State
  const [twilioSid, setTwilioSid] = useState('');
  const [twilioToken, setTwilioToken] = useState('');
  const [twilioNumber, setTwilioNumber] = useState('+91');

  // Vapi State
  const [vapiKey, setVapiKey] = useState('');
  const [vapiAssistantId, setVapiAssistantId] = useState('');

  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Load from LocalStorage
      const savedProvider = localStorage.getItem('krs_provider') as any;
      if (savedProvider) setProvider(savedProvider);

      setTwilioSid(localStorage.getItem('krs_twilio_sid') || '');
      setTwilioToken(localStorage.getItem('krs_twilio_token') || '');
      setTwilioNumber(localStorage.getItem('krs_twilio_number') || '+91 ');
      
      setVapiKey(localStorage.getItem('krs_vapi_key') || '');
      setVapiAssistantId(localStorage.getItem('krs_vapi_id') || '');
      setIsSaved(false);
    }
  }, [isOpen]);

  const handleSave = () => {
    setIsSaving(true);
    
    // Simulate API check / Save delay
    setTimeout(() => {
        localStorage.setItem('krs_provider', provider);
        
        localStorage.setItem('krs_twilio_sid', twilioSid);
        localStorage.setItem('krs_twilio_token', twilioToken);
        localStorage.setItem('krs_twilio_number', twilioNumber);
        
        localStorage.setItem('krs_vapi_key', vapiKey);
        localStorage.setItem('krs_vapi_id', vapiAssistantId);

        setIsSaving(false);
        setIsSaved(true);
        
        // Auto close after success
        setTimeout(() => onClose(), 1500);
    }, 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-slate-50 shrink-0">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Settings size={20} className="text-slate-600" />
            Telephony Configuration
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 transition-colors">
            <X size={20} className="text-slate-500" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 space-y-6 overflow-y-auto">
            
            {/* Provider Toggle */}
            <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Active Calling System</label>
                <div className="grid grid-cols-3 gap-3">
                    <button 
                        onClick={() => setProvider('simulation')}
                        className={`relative p-3 rounded-xl border text-sm font-medium transition-all flex flex-col items-center gap-2 ${
                            provider === 'simulation' 
                            ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500 shadow-sm' 
                            : 'bg-white border-gray-200 text-slate-600 hover:border-blue-200 hover:bg-slate-50'
                        }`}
                    >
                        <Smartphone size={20} className={provider === 'simulation' ? 'text-blue-600' : 'text-slate-400'} />
                        <span>KRS AI Sim</span>
                        {provider === 'simulation' && <div className="absolute top-2 right-2 w-2 h-2 bg-blue-500 rounded-full"></div>}
                    </button>

                    <button 
                        onClick={() => setProvider('twilio')}
                        className={`relative p-3 rounded-xl border text-sm font-medium transition-all flex flex-col items-center gap-2 ${
                            provider === 'twilio' 
                            ? 'bg-red-50 border-red-500 text-red-700 ring-1 ring-red-500 shadow-sm' 
                            : 'bg-white border-gray-200 text-slate-600 hover:border-red-200 hover:bg-slate-50'
                        }`}
                    >
                        <Globe size={20} className={provider === 'twilio' ? 'text-red-600' : 'text-slate-400'} />
                        <span>Twilio</span>
                        {provider === 'twilio' && <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full"></div>}
                    </button>

                    <button 
                        onClick={() => setProvider('vapi')}
                        className={`relative p-3 rounded-xl border text-sm font-medium transition-all flex flex-col items-center gap-2 ${
                            provider === 'vapi' 
                            ? 'bg-purple-50 border-purple-500 text-purple-700 ring-1 ring-purple-500 shadow-sm' 
                            : 'bg-white border-gray-200 text-slate-600 hover:border-purple-200 hover:bg-slate-50'
                        }`}
                    >
                        <Key size={20} className={provider === 'vapi' ? 'text-purple-600' : 'text-slate-400'} />
                        <span>Vapi.ai</span>
                        {provider === 'vapi' && <div className="absolute top-2 right-2 w-2 h-2 bg-purple-500 rounded-full"></div>}
                    </button>
                </div>
            </div>

            {/* Config Sections */}
            <div className="bg-slate-50 rounded-xl p-5 border border-slate-100">
                
                {provider === 'simulation' && (
                    <div className="text-sm text-slate-600 space-y-2 animate-in fade-in">
                        <div className="flex items-center gap-2 text-blue-700 font-semibold">
                            <Check size={16} />
                            AI Smart Simulation Active
                        </div>
                        <p>Calls utilize the <strong>Gemini Live API</strong> to realistically simulate client conversations. This mode is free and requires no external telephony keys.</p>
                        <p className="text-xs text-slate-400 mt-2 border-t border-slate-200 pt-2">Ideal for training and roleplay.</p>
                    </div>
                )}

                {provider === 'twilio' && (
                    <div className="space-y-4 animate-in fade-in">
                        <div className="flex items-center gap-2 text-red-700 font-semibold mb-2">
                            <Settings size={16} />
                            Twilio SIP / Voice Setup
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Account SID</label>
                            <input 
                                type="text" 
                                value={twilioSid}
                                onChange={(e) => setTwilioSid(e.target.value)}
                                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-red-500 outline-none text-sm font-mono" 
                                placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" 
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Auth Token</label>
                            <input 
                                type="password" 
                                value={twilioToken}
                                onChange={(e) => setTwilioToken(e.target.value)}
                                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-red-500 outline-none text-sm font-mono" 
                                placeholder="••••••••••••••••••••••••" 
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Outgoing Caller ID</label>
                            <div className="relative">
                                <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1 border-r border-gray-200 pr-2">
                                     <span className="text-lg">🇮🇳</span>
                                </div>
                                <input 
                                    type="text" 
                                    value={twilioNumber}
                                    onChange={(e) => setTwilioNumber(e.target.value)}
                                    className="w-full pl-14 pr-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-red-500 outline-none text-sm font-mono" 
                                    placeholder="+91 98765 43210" 
                                />
                            </div>
                            <p className="flex items-start gap-1 mt-2 text-[10px] text-slate-500 bg-white p-2 rounded border border-slate-100">
                                <Info size={12} className="shrink-0 mt-0.5 text-blue-500" />
                                For India (+91) calling, ensure you have submitted DLT registration documents in the Twilio Console to avoid call blocking.
                            </p>
                        </div>
                    </div>
                )}

                 {provider === 'vapi' && (
                    <div className="space-y-4 animate-in fade-in">
                        <div className="flex items-center gap-2 text-purple-700 font-semibold mb-2">
                            <Key size={16} />
                            Vapi.ai Assistant Config
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Private API Key</label>
                            <input 
                                type="password" 
                                value={vapiKey}
                                onChange={(e) => setVapiKey(e.target.value)}
                                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-sm font-mono" 
                                placeholder="sk-vapi-..." 
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Assistant ID (UUID)</label>
                            <input 
                                type="text" 
                                value={vapiAssistantId}
                                onChange={(e) => setVapiAssistantId(e.target.value)}
                                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-sm font-mono" 
                                placeholder="e.g. 550e8400-e29b-..." 
                            />
                        </div>
                    </div>
                )}

            </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-between items-center shrink-0">
             <div className="text-xs text-slate-400">
                {isSaved ? <span className="text-green-600 font-medium flex items-center gap-1"><Check size={12}/> Settings saved successfully!</span> : 'Changes save locally.'}
             </div>
             <button 
                onClick={handleSave}
                disabled={isSaving}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-medium text-white transition-all shadow-md ${
                    isSaved ? 'bg-green-600 hover:bg-green-700' : 'bg-slate-900 hover:bg-slate-800'
                }`}
            >
                {isSaving ? <Loader2 size={18} className="animate-spin" /> : isSaved ? <Check size={18} /> : <Save size={18} />}
                {isSaved ? 'Saved' : 'Save Configuration'}
            </button>
        </div>
      </div>
    </div>
  );
};