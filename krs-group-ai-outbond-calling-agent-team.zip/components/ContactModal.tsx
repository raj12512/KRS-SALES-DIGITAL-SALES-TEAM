import React, { useState, useEffect } from 'react';
import { Lead, LeadFormData } from '../types';
import { parseLeadInfo } from '../services/geminiService';
import { X, Sparkles, Loader2, Building, Home, MapPin, Phone, Globe } from 'lucide-react';

interface LeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: LeadFormData) => Promise<void>;
  initialData?: Lead;
  title: string;
}

const PROPERTY_TYPES = ['House', 'Apartment', 'Condo', 'Commercial', 'Land', 'Other'];

const COUNTRY_CODES = [
  { code: '+91', country: 'IN', label: '🇮🇳 +91' },
  { code: '+1', country: 'US', label: '🇺🇸 +1' },
  { code: '+44', country: 'UK', label: '🇬🇧 +44' },
  { code: '+971', country: 'AE', label: '🇦🇪 +971' },
  { code: '+61', country: 'AU', label: '🇦🇺 +61' },
  { code: '', country: 'Other', label: '🌍 Other' }
];

export const LeadModal: React.FC<LeadModalProps> = ({ 
  isOpen, 
  onClose, 
  onSubmit, 
  initialData,
  title 
}) => {
  const [activeTab, setActiveTab] = useState<'form' | 'ai'>('form');
  
  // Split phone state
  const [countryCode, setCountryCode] = useState('+91');
  const [localPhone, setLocalPhone] = useState('');
  
  const [formData, setFormData] = useState<Omit<LeadFormData, 'phone'>>({ 
    name: '', 
    city: '',
    propertyType: 'House'
  });
  
  const [aiInput, setAiInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAiProcessing, setIsAiProcessing] = useState(false);

  // Helper to split full phone into code + local
  const parsePhoneToState = (fullPhone: string) => {
    const cleanPhone = fullPhone.trim();
    const foundCode = COUNTRY_CODES.find(c => c.code && cleanPhone.startsWith(c.code));
    
    if (foundCode) {
      setCountryCode(foundCode.code);
      setLocalPhone(cleanPhone.replace(foundCode.code, '').trim());
    } else {
      // If no matching code found, or it's just a local number
      // If it looks like a US number (10 digits) without code, maybe default to +91 or +1 depending on context
      // For now, default to "Other" or keep existing countryCode if set
      setLocalPhone(cleanPhone);
    }
  };

  useEffect(() => {
    if (isOpen) {
      if (initialData) {
        setFormData({ 
          name: initialData.name, 
          city: initialData.city,
          propertyType: initialData.propertyType
        });
        parsePhoneToState(initialData.phone);
        setActiveTab('form');
      } else {
        setFormData({ name: '', city: '', propertyType: 'House' });
        setCountryCode('+91');
        setLocalPhone('');
        setActiveTab('form');
      }
      setAiInput('');
    }
  }, [isOpen, initialData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      // Combine phone
      const fullPhone = countryCode 
        ? `${countryCode} ${localPhone}`.trim() 
        : localPhone.trim();

      await onSubmit({
        ...formData,
        phone: fullPhone
      });
      onClose();
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAiParse = async () => {
    if (!aiInput.trim()) return;
    setIsAiProcessing(true);
    try {
      const parsed = await parseLeadInfo(aiInput);
      
      setFormData(prev => ({
        ...prev,
        name: parsed.name || prev.name,
        city: parsed.city || prev.city,
        propertyType: (parsed.propertyType as any) || prev.propertyType
      }));

      if (parsed.phone) {
        parsePhoneToState(parsed.phone);
      }

      setActiveTab('form');
    } catch (error) {
      alert("Failed to parse lead info. Please try again.");
    } finally {
      setIsAiProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden transform transition-all border border-slate-100">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-slate-50">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <Building size={20} className="text-blue-600" />
            {title}
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 transition-colors">
            <X size={20} className="text-slate-500" />
          </button>
        </div>

        {/* Tabs */}
        {!initialData && (
          <div className="flex border-b border-gray-100">
            <button
              onClick={() => setActiveTab('form')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'form' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
              }`}
            >
              Manual Entry
            </button>
            <button
              onClick={() => setActiveTab('ai')}
              className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
                activeTab === 'ai' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Sparkles size={16} />
              AI Magic Paste
            </button>
          </div>
        )}

        <div className="p-6">
          {activeTab === 'ai' ? (
            <div className="space-y-4">
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                <p className="text-sm text-blue-700">
                  Paste an email signature, WhatsApp message, or notes. We'll extract the Name, Phone, City, and Property Type automatically.
                </p>
              </div>
              <textarea
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                placeholder="Ex: Need a 3BHK Flat in Mumbai for Rajesh Kumar, contact +91 98765 43210."
                className="w-full h-32 p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm font-sans"
              />
              <button
                onClick={handleAiParse}
                disabled={isAiProcessing || !aiInput.trim()}
                className="w-full py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all shadow-sm"
              >
                {isAiProcessing ? (
                  <>
                    <Loader2 size={18} className="animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles size={18} />
                    Extract Lead Data
                  </>
                )}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Lead Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all bg-slate-50 focus:bg-white"
                  placeholder="e.g. Rahul Sharma"
                />
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Phone Number</label>
                <div className="flex gap-2">
                    <div className="relative w-32 shrink-0">
                        <select
                            value={countryCode}
                            onChange={(e) => setCountryCode(e.target.value)}
                            className="w-full px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-slate-50 focus:bg-white appearance-none text-sm"
                        >
                            {COUNTRY_CODES.map(c => (
                                <option key={c.country} value={c.code}>{c.label}</option>
                            ))}
                        </select>
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
                             <Globe size={12} />
                        </div>
                    </div>
                    <input
                    type="tel"
                    required
                    value={localPhone}
                    onChange={(e) => setLocalPhone(e.target.value)}
                    className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all bg-slate-50 focus:bg-white"
                    placeholder="98765 43210"
                    />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">City</label>
                    <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all bg-slate-50 focus:bg-white"
                    placeholder="e.g. Bangalore"
                    />
                </div>
                <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Property Type</label>
                    <select
                        value={formData.propertyType}
                        onChange={(e) => setFormData({ ...formData, propertyType: e.target.value as any })}
                        className="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all bg-slate-50 focus:bg-white appearance-none"
                    >
                        {PROPERTY_TYPES.map(type => (
                            <option key={type} value={type}>{type}</option>
                        ))}
                    </select>
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-colors shadow-md shadow-blue-200"
                >
                  {isLoading && <Loader2 size={18} className="animate-spin" />}
                  {initialData ? 'Update Lead' : 'Save Lead'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};