import React, { useState, useRef } from 'react';
import { X, Upload, FileText, AlertCircle, Loader2, Check } from 'lucide-react';
import { LeadFormData } from '../types';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (leads: LeadFormData[]) => Promise<void>;
}

export const CsvImportModal: React.FC<CsvImportModalProps> = ({ isOpen, onClose, onImport }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<LeadFormData[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type !== 'text/csv' && !selectedFile.name.endsWith('.csv')) {
        setError('Please upload a valid CSV file.');
        return;
      }
      setFile(selectedFile);
      parseCsv(selectedFile);
    }
  };

  const parseCsv = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split('\n');
        
        // Simple heuristic parser: Assume headers or order: Name, Phone, City, Type
        const parsedLeads: LeadFormData[] = [];
        
        // Skip header if present (heuristic: check if first row contains "name" or "phone")
        let startIndex = 0;
        if (lines[0].toLowerCase().includes('name') || lines[0].toLowerCase().includes('phone')) {
          startIndex = 1;
        }

        for (let i = startIndex; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          
          const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
          if (cols.length < 2) continue; // Need at least name and phone

          parsedLeads.push({
            name: cols[0] || 'Unknown',
            phone: cols[1] || '',
            city: cols[2] || 'Unknown',
            propertyType: (['House', 'Apartment', 'Condo', 'Commercial', 'Land'].includes(cols[3]) ? cols[3] as any : 'Other')
          });
        }

        if (parsedLeads.length === 0) {
            setError("No valid leads found in CSV. Ensure format: Name, Phone, City, Type");
        } else {
            setError(null);
            setPreview(parsedLeads);
        }
      } catch (err) {
        setError("Failed to parse CSV file.");
      }
    };
    reader.readAsText(file);
  };

  const handleImport = async () => {
    setIsProcessing(true);
    try {
      await onImport(preview);
      onClose();
      setFile(null);
      setPreview([]);
    } catch (err) {
      setError("Import failed.");
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-100">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-slate-50">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Upload size={20} className="text-blue-600" />
            Import Leads CSV
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 transition-colors">
            <X size={20} className="text-slate-500" />
          </button>
        </div>

        <div className="p-6">
            {!file ? (
                <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:bg-slate-50 hover:border-blue-400 transition-all cursor-pointer group"
                >
                    <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                        <FileText size={24} className="text-blue-600" />
                    </div>
                    <p className="text-sm font-medium text-slate-700">Click to upload CSV</p>
                    <p className="text-xs text-slate-400 mt-1">Format: Name, Phone (e.g. +91...), City, Property Type</p>
                    <input 
                        ref={fileInputRef} 
                        type="file" 
                        accept=".csv" 
                        className="hidden" 
                        onChange={handleFileChange} 
                    />
                </div>
            ) : (
                <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                                <FileText size={16} className="text-green-600" />
                            </div>
                            <div className="text-sm">
                                <p className="font-medium text-slate-700">{file.name}</p>
                                <p className="text-slate-500 text-xs">{preview.length} leads found</p>
                            </div>
                        </div>
                        <button onClick={() => { setFile(null); setPreview([]); }} className="text-slate-400 hover:text-red-500">
                            <X size={18} />
                        </button>
                    </div>

                    {error && (
                        <div className="p-3 bg-red-50 text-red-700 text-sm rounded-lg flex items-center gap-2">
                            <AlertCircle size={16} />
                            {error}
                        </div>
                    )}

                    <div className="max-h-40 overflow-y-auto border border-slate-200 rounded-lg text-xs">
                        <table className="w-full text-left">
                            <thead className="bg-slate-50 sticky top-0">
                                <tr>
                                    <th className="p-2 font-medium text-slate-500">Name</th>
                                    <th className="p-2 font-medium text-slate-500">Phone</th>
                                    <th className="p-2 font-medium text-slate-500">City</th>
                                    <th className="p-2 font-medium text-slate-500">Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                {preview.slice(0, 10).map((l, i) => (
                                    <tr key={i} className="border-t border-slate-100">
                                        <td className="p-2 text-slate-700">{l.name}</td>
                                        <td className="p-2 text-slate-600">{l.phone}</td>
                                        <td className="p-2 text-slate-600">{l.city}</td>
                                        <td className="p-2 text-slate-600">{l.propertyType}</td>
                                    </tr>
                                ))}
                                {preview.length > 10 && (
                                    <tr>
                                        <td colSpan={4} className="p-2 text-center text-slate-400 italic">
                                            ...and {preview.length - 10} more
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                    <div className="flex gap-3">
                        <button
                            onClick={() => { setFile(null); setPreview([]); }}
                            className="flex-1 py-2.5 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleImport}
                            disabled={isProcessing || !!error}
                            className="flex-1 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-colors shadow-sm"
                        >
                            {isProcessing ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
                            Import {preview.length} Leads
                        </button>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};