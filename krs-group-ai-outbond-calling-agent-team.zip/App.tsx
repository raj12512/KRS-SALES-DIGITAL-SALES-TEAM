import React, { useEffect, useState, useRef } from 'react';
import { Plus, Search, MapPin, Phone, Trash2, Edit2, Loader2, Building2, LayoutGrid, Home, FileText, CalendarClock, PhoneCall, History, Bot, Mic, Upload, PlayCircle, Settings, GripHorizontal } from 'lucide-react';
import { Lead, LeadFormData, CallLog } from './types';
import { storageService } from './services/storageService';
import { LeadModal } from './components/ContactModal';
import { ScriptGeneratorModal } from './components/ScriptGeneratorModal';
import { ScheduleModal } from './components/ScheduleModal';
import { ActiveCallModal } from './components/ActiveCallModal';
import { LiveAgentModal } from './components/LiveAgentModal';
import { CsvImportModal } from './components/CsvImportModal';
import { PowerDialerModal } from './components/PowerDialerModal';
import { SettingsModal } from './components/SettingsModal';
import { DialpadModal } from './components/DialpadModal';

// Custom Logo Component
const KrsLogo = () => (
  <svg viewBox="0 0 200 130" className="h-14 w-auto drop-shadow-sm" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Sun Rays */}
    <path d="M100 5 L100 35" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
    <path d="M140 15 L130 40" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
    <path d="M60 15 L70 40" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
    <path d="M170 45 L140 55" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
    <path d="M30 45 L60 55" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
    <path d="M180 80 L145 80" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
    <path d="M20 80 L55 80" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
    
    {/* Main Text */}
    <text x="100" y="95" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="65" fill="#DC2626" textAnchor="middle" letterSpacing="-2">KRS</text>
    
    {/* Sub Text */}
    <text x="100" y="115" fontFamily="Arial, sans-serif" fontWeight="bold" fontSize="16" fill="#334155" textAnchor="middle" letterSpacing="6">GROUP</text>
    
    {/* Swoosh */}
    <path d="M20 105 Q 100 145 180 95" stroke="#0D9488" strokeWidth="6" fill="none" strokeLinecap="round" opacity="0.8" />
  </svg>
);

export default function App() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isScriptModalOpen, setIsScriptModalOpen] = useState(false);
  const [isLiveAgentOpen, setIsLiveAgentOpen] = useState(false);
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);
  const [isPowerDialerOpen, setIsPowerDialerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isDialpadOpen, setIsDialpadOpen] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | undefined>(undefined);
  
  // Scheduling State
  const [schedulingLeadId, setSchedulingLeadId] = useState<string | null>(null);
  
  // Active Call State
  const [activeCallLead, setActiveCallLead] = useState<Lead | null>(null);

  // Auto-Dialer Ref to prevent multiple triggers
  const isCallInProgressRef = useRef(false);

  useEffect(() => {
    loadLeads();
  }, []);

  // --- Auto-Dialer Simulation Engine ---
  useEffect(() => {
    const checkSchedule = () => {
      // Don't trigger if we are already in a call or power dialer
      if (isCallInProgressRef.current || isPowerDialerOpen) return;

      const now = Date.now();
      
      // Find a lead that is due for a call (scheduled time <= now)
      const dueLead = leads.find(l => 
        l.scheduledCallTime && 
        l.scheduledCallTime <= now && 
        l.scheduledCallTime > (now - 60000) // Only pick up calls due within the last minute (avoid old missed calls spamming)
      );

      if (dueLead) {
        triggerCall(dueLead);
      }
    };

    // Check every 5 seconds
    const intervalId = setInterval(checkSchedule, 5000);
    return () => clearInterval(intervalId);
  }, [leads, isPowerDialerOpen]);

  const triggerCall = (lead: Lead) => {
    isCallInProgressRef.current = true;
    setActiveCallLead(lead);
    
    // Play a ringtone effect here if desired
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/1359/1359-preview.mp3'); // Simple beep
    audio.volume = 0.2;
    audio.play().catch(() => {});
  };

  const loadLeads = async () => {
    setIsLoading(true);
    try {
      const data = await storageService.getLeads();
      setLeads(data);
    } catch (error) {
      console.error("Failed to load leads", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreate = async (data: LeadFormData) => {
    try {
      await storageService.saveLead(data);
      await loadLeads();
    } catch (error) {
      console.error("Failed to create", error);
    }
  };

  const handleImportCsv = async (data: LeadFormData[]) => {
    try {
      await storageService.saveLeads(data);
      await loadLeads();
    } catch (error) {
      console.error("Failed to import", error);
    }
  };

  const handleUpdate = async (data: LeadFormData) => {
    if (!editingLead) return;
    try {
      await storageService.updateLead(editingLead.id, data);
      await loadLeads();
    } catch (error) {
      console.error("Failed to update", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this lead?')) return;
    try {
      await storageService.deleteLead(id);
      await loadLeads();
    } catch (error) {
      console.error("Failed to delete", error);
    }
  };

  const handleSchedule = async (timestamp: number) => {
    if (!schedulingLeadId) return;
    try {
      await storageService.updateLead(schedulingLeadId, { scheduledCallTime: timestamp });
      setSchedulingLeadId(null);
      await loadLeads();
    } catch (error) {
      console.error("Failed to schedule", error);
    }
  };

  const handleCallLog = async (id: string, log: CallLog) => {
    // Helper to log calls from Power Dialer without reload flicker
    try {
        const lead = leads.find(l => l.id === id);
        if (lead) {
            await storageService.updateLead(id, {
                scheduledCallTime: undefined,
                callHistory: [...(lead.callHistory || []), log]
            });
            // Update local state partially to avoid full reload
            setLeads(prev => prev.map(l => l.id === id ? { ...l, scheduledCallTime: undefined, callHistory: [...(l.callHistory || []), log] } : l));
        }
    } catch (error) {
        console.error("Failed to log call", error);
    }
  };

  const handleCallComplete = async (status: 'Interested' | 'Not Interested' | 'Call Later', notes?: string, recordingUrl?: string) => {
    if (!activeCallLead) return;
    
    // If it's a temporary lead (from Dialpad), we don't save history to DB unless we want to save the lead first.
    // For now, only save history for existing leads.
    if (!activeCallLead.id.startsWith('temp-')) {
        const newLog: CallLog = {
          id: crypto.randomUUID(),
          timestamp: Date.now(),
          status: status,
          notes: notes || `Direct/Auto call completed. Result: ${status}`,
          recordingUrl: recordingUrl
        };

        try {
          await storageService.updateLead(activeCallLead.id, {
            scheduledCallTime: undefined,
            callHistory: [...(activeCallLead.callHistory || []), newLog]
          });
        } catch (error) {
          console.error("Failed to save call log", error);
        }
        await loadLeads();
    }

    setActiveCallLead(null);
    isCallInProgressRef.current = false;
  };

  const handleDirectCall = (lead: Lead) => {
      isCallInProgressRef.current = true;
      setActiveCallLead(lead);
  };

  const openCreateModal = () => {
    setEditingLead(undefined);
    setIsModalOpen(true);
  };

  const openEditModal = (lead: Lead) => {
    setEditingLead(lead);
    setIsModalOpen(true);
  };

  const filteredLeads = leads.filter(l => 
    l.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    l.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
    l.phone.includes(searchTerm) ||
    l.propertyType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getPropertyColor = (type: string) => {
    switch(type) {
      case 'House': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Apartment': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Commercial': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Land': return 'bg-amber-100 text-amber-800 border-amber-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      {/* Navbar */}
      <nav className="bg-white shadow-sm sticky top-0 z-10 border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              {/* Custom SVG Logo */}
              <KrsLogo />
            </div>
            <div className="flex items-center gap-2 sm:gap-3">
                {/* Tools */}
                <button
                onClick={() => setIsLiveAgentOpen(true)}
                className="hidden lg:inline-flex items-center gap-2 px-3 py-2 text-sm font-medium text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-100 rounded-lg transition-all"
                >
                <Bot size={18} />
                Roleplay
                </button>

                <button
                onClick={() => setIsScriptModalOpen(true)}
                className="hidden md:inline-flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-600 hover:text-blue-600 hover:bg-slate-50 rounded-lg transition-all"
                >
                <FileText size={18} />
                Script Gen
                </button>

                <div className="h-6 w-px bg-slate-200 hidden sm:block"></div>
                
                {/* Dialpad Button */}
                <button
                onClick={() => setIsDialpadOpen(true)}
                className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border border-transparent hover:border-slate-200 relative group"
                title="Direct Dial"
                >
                    <GripHorizontal size={20} />
                    <span className="absolute top-full mt-1 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">Dialpad</span>
                </button>

                {/* Actions */}
                <button
                onClick={() => setIsCsvModalOpen(true)}
                className="hidden sm:inline-flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 border border-slate-200 rounded-lg transition-all"
                >
                <Upload size={18} />
                Import CSV
                </button>

                <button
                onClick={openCreateModal}
                className="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-lg shadow-md shadow-blue-200 text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                >
                <Plus size={18} />
                <span className="hidden xs:inline">New Lead</span>
                </button>

                <button
                  onClick={() => setIsSettingsOpen(true)}
                  className="p-2 rounded-full text-slate-500 hover:bg-slate-100 transition-colors"
                >
                  <Settings size={20} />
                </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Stats / Header */}
        <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
                <h2 className="text-2xl font-bold text-slate-900">Active Leads</h2>
                <p className="text-slate-500 text-sm mt-1">Manage, track, and auto-dial your potential clients.</p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                 {/* Power Dialer Button */}
                 <button
                    onClick={() => setIsPowerDialerOpen(true)}
                    disabled={filteredLeads.length === 0}
                    className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-900 text-white rounded-xl font-medium shadow-lg hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:-translate-y-0.5"
                 >
                    <PlayCircle size={18} className="text-green-400" />
                    Start Campaign (Radhey Radhey)
                    <span className="bg-slate-700 text-xs px-2 py-0.5 rounded-full text-slate-300 ml-1">{filteredLeads.length}</span>
                 </button>

                {/* Search Bar */}
                <div className="relative w-full sm:w-64">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={16} className="text-slate-400" />
                    </div>
                    <input
                        type="text"
                        className="block w-full pl-9 pr-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow shadow-sm"
                        placeholder="Search leads..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>
        </div>

        {/* Content Area */}
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 size={32} className="text-blue-600 animate-spin mb-3" />
            <p className="text-slate-500 text-sm">Fetching leads...</p>
          </div>
        ) : filteredLeads.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl shadow-sm border border-slate-200 border-dashed">
            <div className="mx-auto h-16 w-16 text-slate-300 bg-slate-50 rounded-full flex items-center justify-center mb-4">
               <LayoutGrid size={32} />
            </div>
            <h3 className="text-lg font-medium text-slate-900">No leads found</h3>
            <p className="mt-1 text-slate-500 text-sm">
              {searchTerm ? "No results match your search." : "Import a CSV or add a lead to get started."}
            </p>
            <div className="mt-6 flex justify-center gap-3">
              <button
                onClick={() => setIsCsvModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2 border border-slate-200 text-sm font-medium rounded-md text-slate-700 bg-white hover:bg-slate-50 transition-colors"
              >
                <Upload size={16} />
                Import CSV
              </button>
              <button
                onClick={openCreateModal}
                className="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-50 hover:bg-blue-100 transition-colors"
              >
                <Plus size={16} />
                Add Manually
              </button>
            </div>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filteredLeads.map((lead) => (
              <div
                key={lead.id}
                className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-lg hover:border-blue-200 transition-all group relative overflow-hidden flex flex-col"
              >
                <div className="flex justify-between items-start mb-3">
                   <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${getPropertyColor(lead.propertyType)}`}>
                      {lead.propertyType}
                   </span>
                   
                   {/* Actions */}
                   <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handleDirectCall(lead)}
                      className="p-1.5 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors"
                      title="Call Now"
                    >
                      <Phone size={14} />
                    </button>
                    <button
                      onClick={() => openEditModal(lead)}
                      className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                      title="Edit"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button
                      onClick={() => handleDelete(lead.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors"
                      title="Delete"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                <div className="mb-4">
                    <h3 className="text-lg font-bold text-slate-900 leading-tight truncate">
                    {lead.name}
                    </h3>
                    <div className="mt-4 space-y-2">
                        <div className="flex items-center gap-2.5 text-slate-600">
                            <Phone size={14} className="text-slate-400 shrink-0" />
                            <span className="text-sm font-medium">{lead.phone}</span>
                        </div>
                        <div className="flex items-center gap-2.5 text-slate-600">
                            <MapPin size={14} className="text-slate-400 shrink-0" />
                            <span className="text-sm">{lead.city}</span>
                        </div>
                    </div>
                </div>

                {/* Call Status & Schedule */}
                <div className="mt-auto pt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                     {lead.scheduledCallTime ? (
                       <div className="flex items-center gap-1.5 text-orange-600 bg-orange-50 px-2 py-1 rounded text-xs font-medium">
                          <CalendarClock size={12} />
                          <span>{formatTime(lead.scheduledCallTime)}</span>
                       </div>
                     ) : (
                       <div className="text-xs text-slate-400">No calls scheduled</div>
                     )}

                     <button 
                        onClick={() => setSchedulingLeadId(lead.id)}
                        className="text-xs font-medium text-blue-600 hover:text-blue-700 hover:underline flex items-center gap-1"
                      >
                        <CalendarClock size={12} />
                        Schedule
                      </button>
                  </div>

                  {/* Call History Snippet */}
                  {lead.callHistory && lead.callHistory.length > 0 && (
                    <div className="mt-3 flex items-center gap-2">
                       <History size={12} className="text-slate-400" />
                       <span className="text-xs text-slate-500">Last: </span>
                       <span className={`text-xs font-medium ${
                         lead.callHistory[lead.callHistory.length - 1].status === 'Interested' ? 'text-green-600' :
                         lead.callHistory[lead.callHistory.length - 1].status === 'Not Interested' ? 'text-red-500' : 'text-amber-600'
                       }`}>
                         {lead.callHistory[lead.callHistory.length - 1].status}
                       </span>
                    </div>
                  )}
                </div>
                
                <div className="absolute bottom-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
                    <Home size={64} />
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Modals */}
      <LeadModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={editingLead ? handleUpdate : handleCreate}
        initialData={editingLead}
        title={editingLead ? 'Edit Property Lead' : 'Add New Lead'}
      />

      <ScriptGeneratorModal 
        isOpen={isScriptModalOpen}
        onClose={() => setIsScriptModalOpen(false)}
      />

      <CsvImportModal 
        isOpen={isCsvModalOpen} 
        onClose={() => setIsCsvModalOpen(false)}
        onImport={handleImportCsv}
      />

      <ScheduleModal 
        isOpen={!!schedulingLeadId}
        onClose={() => setSchedulingLeadId(null)}
        onSchedule={handleSchedule}
      />
      
      <LiveAgentModal 
        isOpen={isLiveAgentOpen}
        onClose={() => setIsLiveAgentOpen(false)}
      />
      
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      <DialpadModal
        isOpen={isDialpadOpen}
        onClose={() => setIsDialpadOpen(false)}
        onCall={handleDirectCall}
      />

      {/* Power Dialer - Full Screen Mode */}
      {isPowerDialerOpen && (
          <PowerDialerModal 
            queue={filteredLeads}
            onClose={() => setIsPowerDialerOpen(false)}
            onUpdateLead={handleCallLog}
          />
      )}

      {/* Single Direct Call (Smart AI) */}
      {activeCallLead && !isPowerDialerOpen && (
        <ActiveCallModal 
          lead={activeCallLead} 
          onComplete={handleCallComplete} 
        />
      )}
    </div>
  );
}