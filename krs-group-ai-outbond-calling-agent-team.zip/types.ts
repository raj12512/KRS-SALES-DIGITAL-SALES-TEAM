
export interface CallLog {
  id: string;
  timestamp: number;
  status: 'Interested' | 'Not Interested' | 'Call Later';
  notes?: string;
  recordingUrl?: string;
}

export interface Lead {
  id: string;
  name: string;
  phone: string;
  city: string;
  propertyType: 'House' | 'Apartment' | 'Condo' | 'Commercial' | 'Land' | 'Other';
  createdAt: number;
  scheduledCallTime?: number; // Timestamp for next call
  callHistory?: CallLog[];
}

export type LeadFormData = Omit<Lead, 'id' | 'createdAt' | 'callHistory'>;

export interface StorageService {
  getLeads: () => Promise<Lead[]>;
  saveLead: (lead: LeadFormData) => Promise<Lead>;
  saveLeads: (leads: LeadFormData[]) => Promise<Lead[]>;
  updateLead: (id: string, lead: Partial<Lead>) => Promise<Lead>;
  deleteLead: (id: string) => Promise<void>;
}
